#ifndef PARAMS_LIB
#define PARAMS_LIB

#define NMAX 2097151

#define N_TESTS 1

//#define DEBUG_PRINT 1

#ifdef DEBUG_PRINT
	#define WIDTH 10
	#define HEIGHT 10
#else
	#define WIDTH 600
	#define HEIGHT 400
#endif

#endif
